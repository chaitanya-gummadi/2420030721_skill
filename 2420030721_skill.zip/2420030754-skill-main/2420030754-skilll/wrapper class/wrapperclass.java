package neww;

public class wrapperclass {
 public static void main(String args[]) {

	 Integer a= 564;
	 Boolean b=true;
	 Double d=9.876d;
	 int c=10;
	 System.out.println(a.toString().length());
	 System.out.println(d.toString().length());
 }
 }
 
