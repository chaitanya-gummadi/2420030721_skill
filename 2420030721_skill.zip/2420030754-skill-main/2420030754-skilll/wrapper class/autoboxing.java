package neww;

public class autoboxing {
 public static void main(String args[]) {
	 //auto boxing
	 int a=10;
	 Integer obj =a;
	 System.out.println("Autoboxing" + obj);
	 
	 //unboxing
	 Integer ob1=20;
	 int b=ob1;
	 System.out.println("unboxing"+b);
 }
}
