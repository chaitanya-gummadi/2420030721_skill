package neww;

public class manual_casting {
	public static void main(String args[]) {
		 double a=10;
		 long b= (long) a;
		 System.out.println("this is manual casting"+b);
		}
		
}
