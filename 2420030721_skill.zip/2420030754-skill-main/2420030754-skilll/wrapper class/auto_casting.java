package neww;

public class auto_casting {
public static void main(String args[]) {
 int a=10;
 double b=a;
 System.out.println("this is auto casting"+b);
}
}
